<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>registarion on MAGAZIN</title>
  
  
  
      <link rel="stylesheet" href="css/stil.css">

  
</head>
<BODY>
<?php
 require('connect.php');

     if (isset($_POST['username']) && isset($_POST['password'])){
         $username = $_POST['username'];
         $email = $_POST['email'];
         $password = $_POST['password'];

         $query = "INSERT INTO users (username, password, email) VALUES ('$username', '$email', '$password')";
         $result = mysqli_query($connection, $query);

         if($result){
             $smsg = "Регистрация прошла успешно!";
         } 
         else {
             $smsg = "Ошибка";
         }
     }
     ?>
     <div id="wrapper">
         <div class="register">
             <form  name="register" method="POST">

             <?php if(isset($smsg)){ ?><div class="alert_d" role="alert"><?php echo $smsg;?></div><?php }?>
             <?php if(isset($fsmsg)){ ?><div class="alert_s" role="alert"><?php echo $fsmsg;?></div><?php }?>

             <input name="email" type="email" value="" placeholder="Введите почту" required>
             <input name="username"  type="username" value="" placeholder="Введите имя" required>
             <input name="password" type="password" value="" placeholder="Введите пароль" required>
             <button type="submit" value="Отправить">&#xf0da;</button>
             <p>Забыли пароль? <a href="#">Нажмите здесь</a></p>
             </form>
         </div>
    </div>
     </body>
</html>